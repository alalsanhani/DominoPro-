## تفعيل الأونلاين

1. أنشئ مشروعًا في https://console.firebase.google.com/ .
2. فعّل Authentication → Email/Password.
3. أنشئ Cloud Firestore، وانسخ Project ID وWeb API Key من إعدادات المشروع.
4. Cloud Functions المنشورة تحتاج خطة Blaze وقد تنشأ تكلفة حسب الاستخدام. لم تُفعّل فوترة أو يُنشر خادم نيابة عنك.
5. ثبّت Node.js 22 وFirebase CLI:

```sh
npm install -g firebase-tools
firebase login
```

6. داخل `backend/functions`:

```sh
npm ci
npm test
```

7. داخل `backend`، استبدل YOUR_PROJECT_ID بمعرّفك:

```sh
firebase deploy --project YOUR_PROJECT_ID --only functions:dominoV2,firestore:rules
```

8. داخل تطبيق iOS → أونلاين: أدخل المعرف والمفتاح ثم احفظ.
9. استخدم حسابات مختلفة على 2–4 أجهزة، بنفس إعداد المشروع. أنشئ غرفة، وأرسل الكود، وبعد اكتمال العدد يبدأ المضيف.

الدالة الجديدة `dominoV2` تستخدم `roomsV2`, `profilesV2`, `queuesV2`, `reportsV2`. دالة `domino` القديمة موجودة في المصدر حتى يمكن دعم مستخدمي الإصدارات السابقة، لكن غرفها لا تتصل بالغرف الجديدة. المنطقة الافتراضية `us-central1`. لا يحتاج العميل `google-services.json`؛ الاتصال HTTP مع Firebase ID Token وتجديده.

قواعد Firestore تمنع الوصول المباشر؛ الدالة وحدها تتحقق من العمليات وتعيد البيانات المسموحة. لا تضع Service Account داخل التطبيق.

إذا لم يعمل الاتصال، تحقق من اسم الدالة الجديدة والمنطقة ومعرّف المشروع وتفعيل دخول البريد. رسالة تغير الحالة تتطلب تحديث الغرفة قبل إعادة الحركة. بعد انقطاع الشبكة حدّث لتعرف إن كانت آخر حركة قُبلت بالفعل.

