import Foundation
import Network
import UIKit
import Darwin

/// Protocol: unsigned 32-bit big-endian length, then UTF-8 JSON (1…65536 bytes).
/// All state and callbacks are confined to the main queue.
final class LANTransport {
    var onEvent: (([String: Any]) -> Void)?
    private var listener: NWListener?
    private var links: [Int: NWConnection] = [:]
    private var buffers: [Int: Data] = [:]
    private var pendingBytes: [Int: Int] = [:]
    private var lastReceived: [Int: Date] = [:]
    private var monitor: Timer?
    init() { monitor = Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { [weak self] _ in
        guard let self = self else { return }
        for (peer, time) in self.lastReceived where Date().timeIntervalSince(time) > 20 { self.drop(peer) }
    } }
    deinit { monitor?.invalidate() }
    private var serial = 0
    private var generation = 0
    private let limit = 65536

    func close() {
        generation += 1
        listener?.cancel(); listener = nil
        let old = links.values
        links.removeAll(); buffers.removeAll(); pendingBytes.removeAll(); lastReceived.removeAll()
        for link in old { link.cancel() }
    }
    func host() {
        close()
        let epoch = generation
        do {
            let parameters = NWParameters.tcp
            parameters.allowLocalEndpointReuse = true
            let server = try NWListener(using: parameters, on: NWEndpoint.Port(rawValue: 38426)!)
            listener = server
            server.stateUpdateHandler = { [weak self] state in
                guard let self = self, self.generation == epoch else { return }
                switch state {
                case .ready: self.emit(["type": "hosting", "addresses": Self.addresses()])
                case .failed(let error): self.emit(["type": "error", "message": error.localizedDescription]); self.close()
                default: break
                }
            }
            server.newConnectionHandler = { [weak self] connection in
                guard let self = self, self.generation == epoch, self.links.count < 8 else { connection.cancel(); return }
                self.serial += 1
                self.attach(connection, peer: self.serial, epoch: epoch)
            }
            server.start(queue: .main)
        } catch { emit(["type": "error", "message": error.localizedDescription]) }
    }
    func join(_ address: String) {
        close()
        let connection = NWConnection(host: NWEndpoint.Host(address), port: NWEndpoint.Port(rawValue: 38426)!, using: .tcp)
        attach(connection, peer: 0, epoch: generation)
    }
    private func attach(_ connection: NWConnection, peer: Int, epoch: Int) {
        links[peer] = connection; buffers[peer] = Data(); pendingBytes[peer] = 0
        connection.stateUpdateHandler = { [weak self, weak connection] state in
            guard let self = self, let connection = connection, self.generation == epoch, self.links[peer] === connection else { return }
            switch state {
            case .ready:
                self.lastReceived[peer] = Date()
                self.emit(["type": "connected", "peer": peer])
                self.receive(connection, peer: peer, epoch: epoch)
            case .failed(_), .cancelled: self.drop(peer)
            case .waiting(let error):
                self.emit(["type": "error", "message": error.localizedDescription]); self.drop(peer)
            default: break
            }
        }
        connection.start(queue: .main)
        DispatchQueue.main.asyncAfter(deadline: .now() + 6) { [weak self, weak connection] in
            guard let self = self, let connection = connection, self.generation == epoch, self.links[peer] === connection, self.lastReceived[peer] == nil else { return }
            self.drop(peer)
        }
    }
    private func receive(_ connection: NWConnection, peer: Int, epoch: Int) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 16384) { [weak self, weak connection] data, _, done, error in
            guard let self = self, let connection = connection, self.generation == epoch, self.links[peer] === connection else { return }
            if let data = data, !data.isEmpty {
                self.lastReceived[peer] = Date()
                var buffer = self.buffers[peer] ?? Data()
                buffer.append(data)
                while buffer.count >= 4 {
                    let length = buffer.prefix(4).reduce(0) { ($0 << 8) | Int($1) }
                    guard length > 0 && length <= self.limit else { self.drop(peer); return }
                    if buffer.count < length + 4 { break }
                    let packet = buffer.dropFirst(4).prefix(length)
                    guard let object = try? JSONSerialization.jsonObject(with: Data(packet)), let message = object as? [String: Any] else { self.drop(peer); return }
                    buffer = Data(buffer.dropFirst(length + 4))
                    self.emit(["type": "message", "peer": peer, "message": message])
                }
                self.buffers[peer] = buffer
            }
            if done || error != nil { self.drop(peer); return }
            self.receive(connection, peer: peer, epoch: epoch)
        }
    }
    func send(_ message: [String: Any], peer: Int) {
        guard let connection = links[peer], let body = try? JSONSerialization.data(withJSONObject: message), !body.isEmpty, body.count <= limit else { return }
        let outstanding = (pendingBytes[peer] ?? 0) + body.count + 4
        guard outstanding <= 1048576 else { drop(peer); return }
        pendingBytes[peer] = outstanding
        var length = UInt32(body.count).bigEndian
        var packet = withUnsafeBytes(of: &length) { Data($0) }
        packet.append(body)
        let epoch = generation
        connection.send(content: packet, completion: .contentProcessed { [weak self, weak connection] error in
            guard let self = self, let connection = connection, self.generation == epoch, self.links[peer] === connection else { return }
            self.pendingBytes[peer] = max(0, (self.pendingBytes[peer] ?? 0) - body.count - 4)
            if error != nil { self.drop(peer) }
        })
    }
    private func drop(_ peer: Int) {
        guard let connection = links.removeValue(forKey: peer) else { return }
        buffers.removeValue(forKey: peer); pendingBytes.removeValue(forKey: peer); lastReceived.removeValue(forKey: peer)
        connection.cancel(); emit(["type": "lost", "peer": peer])
    }
    private func emit(_ event: [String: Any]) { onEvent?(event) }
    static func addresses() -> [String] {
        var pointer: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&pointer) == 0, let first = pointer else { return [] }
        defer { freeifaddrs(pointer) }
        var result: [String] = []
        var cursor: UnsafeMutablePointer<ifaddrs>? = first
        while let item = cursor {
            defer { cursor = item.pointee.ifa_next }
            guard let address = item.pointee.ifa_addr, address.pointee.sa_family == UInt8(AF_INET), (item.pointee.ifa_flags & UInt32(IFF_LOOPBACK)) == 0 else { continue }
            let name = String(cString: item.pointee.ifa_name)
            guard name.hasPrefix("en") || name.hasPrefix("bridge") else { continue }
            var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            if getnameinfo(address, socklen_t(address.pointee.sa_len), &host, socklen_t(host.count), nil, 0, NI_NUMERICHOST) == 0 { result.append(String(cString: host)) }
        }
        return Array(Set(result)).sorted()
    }
}
