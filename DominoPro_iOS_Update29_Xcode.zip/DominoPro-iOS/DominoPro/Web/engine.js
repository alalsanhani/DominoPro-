(function(){
'use strict';
const crypto=globalThis.crypto||require('node:crypto').webcrypto;
const randomInt=n=>Math.floor(Math.random()*n);
const id=t=>Math.min(t.a,t.b)*7+Math.max(t.a,t.b),flip=t=>({a:t.b,b:t.a});
const sum=(g,p)=>g.hands[p].reduce((n,t)=>n+(g.mode===5&&t.a+t.b===0?10:t.a+t.b),0);
const sides=g=>g.spinner?4:2;
const end=(g,s)=>g.spinner?(g.arms[s].length?g.arms[s].at(-1).b:g.spinner.a):(s===0?g.board[0].a:g.board.at(-1).b);
function available(g,s){if(!Number.isInteger(s)||s<0||s>=sides(g))return false;if(!g.spinner)return true;if(g.mode===4&&g.arms.some(a=>!a.length))return !g.arms[s].length;return s<2||g.arms[0].length>0&&g.arms[1].length>0;}
const legal=(g,t,s)=>available(g,s)&&(t.a===end(g,s)||t.b===end(g,s));
const hasMove=(g,p)=>g.hands[p].some(t=>Array.from({length:sides(g)},(_,s)=>s).some(s=>legal(g,t,s)));
function spinner(g){if(g.spinner||g.mode<2||g.mode>4)return;const i=g.board.findIndex(t=>t.a===t.b);if(i<0)return;g.spinner=g.board[i];g.arms=[g.board.slice(0,i).reverse().map(flip),g.board.slice(i+1),[],[]];}
function endSum(g){if(!g.spinner){if(g.board.length===1)return g.board[0].a+g.board[0].b;const a=g.board[0],b=g.board.at(-1);return a.a+(a.a===a.b?a.a:0)+b.b+(b.a===b.b?b.b:0);}return g.arms.reduce((n,a,s)=>n+(a.length?a.at(-1).b*(a.at(-1).a===a.at(-1).b?2:1):s<2?g.spinner.a:0),0);}
function addPoints(g,p,n){for(let i=0;i<g.players;i++)if(i===p||(g.teamMode&&g.teams[i]===g.teams[p]))g.scores[i]+=n;}
function teamSum(g,t){return g.hands.reduce((n,_,p)=>n+(g.teams[p]===t?sum(g,p):0),0);}
function record(g){if(g.finished&&!g.roundResults.some(r=>r.round===g.round))g.roundResults.push({round:g.round,winner:g.winner,gained:g.scores.map((n,p)=>n-g.roundStartScores[p]),totals:[...g.scores],remaining:g.hands.map((_,p)=>sum(g,p))});}
function tournament(g){if(g.tournamentRounds&&g.round>=g.tournamentRounds){g.matchFinished=true;const reps=g.teamMode?[g.teams.indexOf(0),g.teams.indexOf(1)]:g.scores.map((_,p)=>p),best=(g.mode===5&&!g.teamMode?Math.min:Math.max)(...reps.map(p=>g.scores[p])),wins=reps.filter(p=>g.scores[p]===best);g.winner=wins.length===1?wins[0]:-1;}}
function scoreEnds(g,p){if(g.mode!==2&&g.mode!==3)return;const n=endSum(g),div=g.mode===2?5:3;if(n>0&&n%div===0){addPoints(g,p,n);g.points=n;if(g.scores[p]>=g.target){g.winner=p;g.finished=true;g.matchFinished=true;record(g);}}}
function finish(g,w){g.finished=true;g.winner=w;g.points=0;if(g.teamMode){if(w>=0){g.points=teamSum(g,1-g.teams[w]);addPoints(g,w,g.points);if(g.scores[w]>=g.target)g.matchFinished=true;}tournament(g);record(g);return;}if(g.mode===5){for(let p=0;p<g.players;p++){const n=sum(g,p);if(n>=13)g.scores[p]+=n;if(g.scores[p]>=g.target)g.matchFinished=true;}if(g.matchFinished){const best=Math.min(...g.scores),winners=g.scores.flatMap((s,i)=>s===best?[i]:[]);g.winner=winners.length===1?winners[0]:-1;}tournament(g);record(g);return;}
 if(w>=0){g.points=g.hands.reduce((n,_,p)=>n+(p===w?0:sum(g,p)),0);if(g.mode===2||g.mode===3)g.points=Math.max(0,g.points-sum(g,w));g.scores[w]+=g.points;if(g.scores[w]>=g.target)g.matchFinished=true;}tournament(g);record(g);}
function blocked(g){if(g.finished||(!g.block&&g.stock.length))return;if(g.hands.some((_,p)=>hasMove(g,p)))return;g.roundBlocked=true;if(g.teamMode){const a=teamSum(g,0),b=teamSum(g,1);finish(g,a===b?-1:g.teams.indexOf(a<b?0:1));return;}const totals=g.hands.map((_,p)=>sum(g,p)),best=Math.min(...totals),ws=totals.flatMap((n,p)=>n===best?[p]:[]);finish(g,ws.length===1?ws[0]:-1);}
function start(options={},prior=null){const mode=options.mode||0,players=options.players||2,target=options.target||100;
 if(!Number.isInteger(players)||players<2||players>4||!Number.isInteger(mode)||mode<0||mode>5||![50,100,150,200].includes(target))throw Error('OPTIONS');
 if(options.teamMode&&(players!==4||!completeTeams(options.teams)))throw Error('TEAM_INVALID');
 const previous=prior&&!prior.matchFinished&&prior.winner>=0&&prior.hands[prior.winner].length===0?prior.winner:-1;
 let g,owner,opening;
 do{const stock=[];for(let a=0;a<=6;a++)for(let b=a;b<=6;b++)stock.push({a,b});for(let i=27;i>0;i--){const j=randomInt(i+1);[stock[i],stock[j]]=[stock[j],stock[i]];}
 g={teamMode:!!options.teamMode,teams:options.teams||[0,1,0,1],teamNames:options.teamNames||["المجموعة 1","المجموعة 2"],tournamentRounds:options.tournamentRounds||0,roundResults:prior&&!prior.matchFinished?prior.roundResults:[],tileStyle:prior&&!prior.matchFinished?prior.tileStyle:randomInt(10),roundBlocked:false,players,mode,target,block:mode===1||mode===5,hands:Array.from({length:players},()=>[]),stock,board:[],arms:[],spinner:null,scores:prior&&!prior.matchFinished?[...prior.scores]:Array(players).fill(0),round:prior&&!prior.matchFinished?prior.round+1:1,roundId:crypto.randomUUID(),finished:false,matchFinished:false,winner:-2,turn:0,points:0};
 for(let n=0;n<7;n++)for(let p=0;p<players;p++)g.hands[p].push(stock.pop());let best=-1;for(let p=0;p<players;p++)if(previous<0||p===previous)for(const t of g.hands[p]){const rank=(t.a===t.b?100:0)+t.a+t.b;if(rank>best){best=rank;owner=p;opening=t;}}
 }while(previous<0&&mode===4&&opening.a!==opening.b);
 g.roundStartScores=[...g.scores];
 g.hands[owner].splice(g.hands[owner].indexOf(opening),1);g.board.push(opening);g.turn=(owner+1)%players;spinner(g);scoreEnds(g,owner);blocked(g);return g;
}
function act(g,p,action,tileId,side){if(g.finished||p!==g.turn)throw Error('NOT_YOUR_TURN');if(action==='play'){
 const i=g.hands[p].findIndex(t=>id(t)===tileId),t=g.hands[p][i];if(!t||!legal(g,t,side))throw Error('ILLEGAL_MOVE');g.hands[p].splice(i,1);g.points=0;
 if(g.spinner){const oriented=t.a===end(g,side)?t:flip(t);g.arms[side].push(oriented);g.board.push(oriented);}else{if(side===0)g.board.unshift(t.b===end(g,0)?t:flip(t));else g.board.push(t.a===end(g,1)?t:flip(t));spinner(g);}
 scoreEnds(g,p);if(g.finished)return;if(!g.hands[p].length){finish(g,p);return;}g.turn=(p+1)%g.players;
 }else if(action==='draw'||action==='drawPick'){if(g.block||!g.stock.length||hasMove(g,p))throw Error('CANNOT_DRAW');const index=action==='drawPick'?side:g.stock.length-1;if(!Number.isInteger(index)||index<0||index>=g.stock.length)throw Error('STOCK_INDEX');g.hands[p].push(g.stock.splice(index,1)[0]);}
 else if(action==='pass'){if(hasMove(g,p)||(!g.block&&g.stock.length))throw Error('CANNOT_PASS');g.turn=(p+1)%g.players;}else throw Error('UNKNOWN_ACTION');blocked(g);
}
function view(g,p){if(!g)return null;return {teamMode:g.teamMode,teams:g.teams,teamNames:g.teamNames,tournamentRounds:g.tournamentRounds,roundResults:g.roundResults,tileStyle:g.tileStyle,roundBlocked:g.roundBlocked,stockChoice:true,players:g.players,mode:g.mode,target:g.target,board:g.board,arms:g.arms,hand:g.hands[p],counts:g.hands.map(h=>h.length),stockCount:g.stock.length,scores:g.scores,round:g.round,roundId:g.roundId,turn:g.turn,winner:g.winner,points:g.points,finished:g.finished,matchFinished:g.matchFinished,block:g.block,endSum:endSum(g),ends:Array.from({length:sides(g)},(_,s)=>end(g,s)),allowed:Array.from({length:sides(g)},(_,s)=>available(g,s)),...(g.spinner?{spinner:g.spinner}:{}),canDraw:!g.finished&&g.turn===p&&!g.block&&g.stock.length>0&&!hasMove(g,p),canPass:!g.finished&&g.turn===p&&!hasMove(g,p)&&(g.block||!g.stock.length),revealed:g.finished?g.hands:[]};}

function completeTeams(a){return Array.isArray(a)&&a.length===4&&[0,1].includes(a[0])&&a[1]===1-a[0]&&[0,1].includes(a[2])&&a[3]===1-a[2];}
function chooseTeam(a,p,t){if(!Number.isInteger(p)||p<0||p>3||![0,1].includes(t)||a[p]>=0||a.slice(0,p).some(v=>v<0)||(p%2&&t!==1-a[p-1]))throw Error('TEAM_CHOICE');a[p]=t;}
function best(g,level=2){const moves=[];for(const t of g.hands[g.turn])for(let s=0;s<sides(g);s++)if(legal(g,t,s)){const exposed=t.a===end(g,s)?t.b:t.a;let score=t.a+t.b;if(level>=2)score+=(t.a===t.b?5:0)+3*g.hands[g.turn].filter(o=>id(o)!==id(t)&&(o.a===exposed||o.b===exposed)).length;if(level>=3){const div=g.mode===2?5:g.mode===3?3:0,n=endSum(g)-end(g,s)+exposed;if(div&&n%div===0)score+=n*4;}moves.push({id:id(t),side:s,score});}return moves.length?(level===0?moves[randomInt(moves.length)]:moves.sort((a,b)=>b.score-a.score)[0]):null;}
function bot(g,level=2){const m=best(g,level);act(g,g.turn,m?'play':!g.block&&g.stock.length?'draw':'pass',m?.id,m?.side);}
function timeout(g){const owner=g.turn;for(let i=0;i<30&&!g.finished&&g.turn===owner;i++)bot(g,2);}
const Engine={start,act,view,id,legal,hasMove,blocked,endSum,sum,bot,best,timeout,completeTeams,chooseTeam};
if(typeof module!=='undefined')module.exports=Engine;else globalThis.Engine=Engine;

})();
