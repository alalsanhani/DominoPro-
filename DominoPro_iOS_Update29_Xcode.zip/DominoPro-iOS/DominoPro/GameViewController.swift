import UIKit
import WebKit

final class GameViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate {
    private var web: WKWebView!
    private let transport = LANTransport()
    override func viewDidLoad() {
        super.viewDidLoad()
        let configuration = WKWebViewConfiguration()
        configuration.userContentController.add(self, name: "domino")
        configuration.allowsInlineMediaPlayback = true
        configuration.mediaTypesRequiringUserActionForPlayback = []
        web = WKWebView(frame: .zero, configuration: configuration)
        web.navigationDelegate = self
        web.isOpaque = false
        web.backgroundColor = UIColor(red: 0.035, green: 0.07, blue: 0.10, alpha: 1)
        web.scrollView.isScrollEnabled = false
        web.scrollView.contentInsetAdjustmentBehavior = .never
        view = web
        transport.onEvent = { [weak self] event in self?.emit(event) }
        NotificationCenter.default.addObserver(self, selector: #selector(inactive), name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(active), name: UIApplication.didBecomeActiveNotification, object: nil)
        if let file = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "Web") { web.loadFileURL(file, allowingReadAccessTo: file.deletingLastPathComponent()) }
    }
    override var prefersStatusBarHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame, message.frameInfo.request.url?.isFileURL == true, let body = message.body as? [String: Any], let command = body["cmd"] as? String else { return }
        switch command {
        case "host": transport.host()
        case "join": if let host = body["host"] as? String, host.count <= 45 { transport.join(host) }
        case "send": if let peer = body["peer"] as? Int, let data = body["message"] as? [String: Any] { transport.send(data, peer: peer) }
        case "close": transport.close()
        case "info": emit(["type": "info", "name": UIDevice.current.name, "addresses": LANTransport.addresses()])
        case "haptic": UIImpactFeedbackGenerator(style: .light).impactOccurred()
        default: break
        }
    }
    private func emit(_ event: [String: Any]) {
        guard let data = try? JSONSerialization.data(withJSONObject: event) else { return }
        web.evaluateJavaScript("window.nativeBase64 && window.nativeBase64('\(data.base64EncodedString())')", completionHandler: nil)
    }
    @objc private func inactive() { emit(["type": "active", "active": false]) }
    @objc private func active() { emit(["type": "active", "active": true]) }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        decisionHandler(navigationAction.request.url?.isFileURL == true ? .allow : .cancel)
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { transport.close(); webView.reload() }
    deinit { NotificationCenter.default.removeObserver(self); transport.close() }
}
