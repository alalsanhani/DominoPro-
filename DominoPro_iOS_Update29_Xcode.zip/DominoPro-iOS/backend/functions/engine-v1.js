'use strict';
const crypto = require('node:crypto');
const id = t => Math.min(t.a,t.b)*7+Math.max(t.a,t.b);
const sum = h => h.reduce((n,t)=>n+t.a+t.b,0);
const left = g => g.board[0].a;
const right = g => g.board[g.board.length-1].b;
const matches = (t,n) => t.a===n||t.b===n;
const legal = (g,t,side) => matches(t,side===0?left(g):right(g));
const hasMove = (g,p) => g.hands[p].some(t=>legal(g,t,0)||legal(g,t,1));
function finish(g,w){g.finished=true;g.winner=w;g.points=w<0?0:sum(g.hands[1-w]);if(w>=0)g.scores[w]+=g.points;}
function blocked(g){if(!g.finished&&(g.block||g.stock.length===0)&&!hasMove(g,0)&&!hasMove(g,1)){const a=sum(g.hands[0]),b=sum(g.hands[1]);finish(g,a===b?-1:a<b?0:1);}}
function start(block=false,prior=null,deck=null){
 const stock=deck?structuredClone(deck):[];
 if(!deck){for(let a=0;a<=6;a++)for(let b=a;b<=6;b++)stock.push({a,b});for(let i=stock.length-1;i>0;i--){const j=crypto.randomInt(i+1);[stock[i],stock[j]]=[stock[j],stock[i]];}}
 const g={hands:[[],[]],stock,board:[],scores:prior?[...prior.scores]:[0,0],round:prior?prior.round+1:1,roundId:crypto.randomUUID(),turn:0,winner:-2,points:0,finished:false,block};
 for(let i=0;i<7;i++){g.hands[0].push(stock.pop());g.hands[1].push(stock.pop());}
 let owner=0,chosen=null,best=-1;
 for(let p=0;p<2;p++)for(const t of g.hands[p]){const rank=(t.a===t.b?100:0)+t.a+t.b;if(rank>best){best=rank;owner=p;chosen=t;}}
 g.hands[owner].splice(g.hands[owner].indexOf(chosen),1);g.board.push(chosen);g.turn=1-owner;blocked(g);return g;
}
function act(g,p,action,tileId,side){
 if(g.finished||p!==g.turn)throw Error('NOT_YOUR_TURN');
 if(action==='play'){
  if(side!==0&&side!==1)throw Error('ILLEGAL_MOVE');
  const i=g.hands[p].findIndex(t=>id(t)===tileId),t=g.hands[p][i];
  if(!t||!legal(g,t,side))throw Error('ILLEGAL_MOVE');
  const flipped={a:t.b,b:t.a};
  if(side===0)g.board.unshift(t.b===left(g)?t:flipped);else g.board.push(t.a===right(g)?t:flipped);
  g.hands[p].splice(i,1);if(g.hands[p].length===0){finish(g,p);return;}g.turn=1-p;
 }else if(action==='draw'){
  if(g.block||g.stock.length===0||hasMove(g,p))throw Error('CANNOT_DRAW');g.hands[p].push(g.stock.pop());
 }else if(action==='pass'){
  if(hasMove(g,p)||(!g.block&&g.stock.length>0))throw Error('CANNOT_PASS');g.turn=1-p;
 }else throw Error('UNKNOWN_ACTION');
 blocked(g);
}
function view(g,p){
 if(!g)return null;
 return {board:g.board,hand:g.hands[p],counts:g.hands.map(h=>h.length),stockCount:g.stock.length,scores:g.scores,round:g.round,roundId:g.roundId,turn:g.turn,winner:g.winner,points:g.points,finished:g.finished,block:g.block,
  canDraw:!g.finished&&g.turn===p&&!g.block&&g.stock.length>0&&!hasMove(g,p),canPass:!g.finished&&g.turn===p&&!hasMove(g,p)&&(g.block||g.stock.length===0),
  revealed:g.finished?g.hands:[]};
}
module.exports={start,act,view,id,hasMove,legal,blocked};
