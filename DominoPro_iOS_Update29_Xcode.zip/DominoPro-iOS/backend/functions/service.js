'use strict';
const crypto=require('node:crypto'),E=require('./engine');
module.exports=function createService(db,fail){
 const ref=(c,id)=>db.collection(c).doc(id),safeId=id=>typeof id==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(id);
 function response(r,uid){const me=r.members.indexOf(uid);if(me<0)fail('NOT_MEMBER');return {code:r.code,status:r.status,version:r.version,me,names:r.names,capacity:r.capacity,members:r.members,options:r.options,chat:r.chat,game:E.view(r.game?JSON.parse(r.game):null,me)};}
 function code(){return Array.from({length:6},()=> 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[crypto.randomInt(32)]).join('');}
 const profile=(uid,name)=>({uid,name:name||'Player',cups:0,wins:0,matches:0,active:'',friends:[],incoming:[],seasonWins:0,season:''});
 const publicProfile=p=>({uid:p.uid,name:p.name,cups:p.cups||0,wins:p.wins||0,matches:p.matches||0,league:(p.cups||0)>=500?'Diamond':(p.cups||0)>=200?'Gold':(p.cups||0)>=50?'Silver':'Bronze'});
 return async request=>{
 if(!request.auth)fail('SIGN_IN_REQUIRED');const uid=request.auth.uid,d=request.data||{},action=d.action,name=typeof d.name==='string'?d.name.trim().slice(0,24):'';
 if(typeof action!=='string')fail('INVALID_REQUEST');
 if(['profile','leaderboard','friends','friendRequest','friendAccept'].includes(action)){
  if(action==='leaderboard'){const rows=await db.collection('profilesV2').orderBy('cups','desc').limit(25).get();return {leaderboard:rows.docs.map(s=>publicProfile(s.data()))};}
  if(action==='friends'){const user=await ref('profilesV2',uid).get();const p=user.exists?user.data():profile(uid,name);const rows=await Promise.all([...(p.friends||[]),...(p.incoming||[])].slice(0,100).map(id=>ref('profilesV2',id).get()));return {friends:rows.filter(s=>s.exists&&(p.friends||[]).includes(s.id)).map(s=>publicProfile(s.data())),incoming:rows.filter(s=>s.exists&&(p.incoming||[]).includes(s.id)).map(s=>publicProfile(s.data()))};}
  return db.runTransaction(async tx=>{const my=ref('profilesV2',uid),doc=await tx.get(my),p=doc.exists?doc.data():profile(uid,name);if(action==='profile'){if(name)p.name=name;tx.set(my,p);return {profile:publicProfile(p)};}
   if(!safeId(d.friendId)||d.friendId===uid)fail('INVALID_FRIEND');const other=ref('profilesV2',d.friendId),odoc=await tx.get(other);if(!odoc.exists)fail('FRIEND_NOT_FOUND');const o=odoc.data();
   if(action==='friendRequest'){if((p.friends||[]).includes(d.friendId))return {ok:true};if((o.incoming||[]).length>=50)fail('TOO_MANY_REQUESTS');o.incoming=[...new Set([...(o.incoming||[]),uid])];tx.set(other,o);tx.set(my,p);}
   else{if(!(p.incoming||[]).includes(d.friendId))fail('NO_INVITE');if(p.friends.length>=50||o.friends.length>=50)fail('FRIEND_LIMIT');p.friends=[...new Set([...p.friends,d.friendId])];o.friends=[...new Set([...o.friends,uid])];p.incoming=p.incoming.filter(id=>id!==d.friendId);tx.set(my,p);tx.set(other,o);}return {ok:true};});
 }
 const requestId=d.requestId;if(action!=='get'&&(typeof requestId!=='string'||!/^[A-Za-z0-9-]{8,80}$/.test(requestId)))fail('INVALID_REQUEST');
 if(action==='create'||action==='quick'){
  const options={mode:Number.isInteger(d.mode)?d.mode:0,players:Number.isInteger(d.players)?d.players:2,target:Number.isInteger(d.target)?d.target:100};
  if(options.mode<0||options.mode>5||options.players<2||options.players>4||![50,100,150,200].includes(options.target))fail('INVALID_OPTIONS');
  const my=ref('profilesV2',uid),newCode=code(),roomRef=ref('roomsV2',newCode),queue=ref('queuesV2',`${options.mode}-${options.players}-${options.target}`);
  return db.runTransaction(async tx=>{
   const u=await tx.get(my),p=u.exists?u.data():profile(uid,name);if(p.active){const old=await tx.get(ref('roomsV2',p.active));if(old.exists&&old.data().status!=='closed'&&old.data().expires>Date.now())return response(old.data(),uid);}
   if(action==='quick'){const q=await tx.get(queue);if(q.exists){const waiting=await tx.get(ref('roomsV2',q.data().code));if(waiting.exists){const r=waiting.data();if(r.status==='waiting'&&r.members.length<r.capacity&&r.expires>Date.now()&&!r.members.includes(uid)){r.members.push(uid);r.names.push(name||p.name);r.version++;p.active=r.code;tx.set(ref('roomsV2',r.code),r);tx.set(my,p);return response(r,uid);}}}}
   const collision=await tx.get(roomRef);if(collision.exists)fail('TRY_AGAIN');
   const r={code:newCode,members:[uid],names:[name||p.name],capacity:options.players,options,status:'waiting',version:1,game:'',chat:[],chatAt:{},lastRequests:{},expires:Date.now()+86400000,ranked:action==='quick'};
   p.active=newCode;if(name)p.name=name;tx.create(roomRef,r);tx.set(my,p);if(action==='quick')tx.set(queue,{code:newCode});return response(r,uid);
  });
 }
 if(typeof d.code!=='string'||!/^[A-Z2-9]{6}$/.test(d.code))fail('INVALID_CODE');const roomRef=ref('roomsV2',d.code);
 return db.runTransaction(async tx=>{
  const doc=await tx.get(roomRef);if(!doc.exists)fail('ROOM_NOT_FOUND');const r=doc.data();if(r.expires<Date.now())fail('ROOM_EXPIRED');
  if(action==='join'){
   if(r.members.includes(uid))return response(r,uid);if(r.status!=='waiting'||r.members.length>=r.capacity)fail('ROOM_FULL');
   const my=ref('profilesV2',uid),u=await tx.get(my),p=u.exists?u.data():profile(uid,name);r.members.push(uid);r.names.push(name||p.name);r.version++;p.active=r.code;tx.set(roomRef,r);tx.set(my,p);return response(r,uid);
  }
  const me=r.members.indexOf(uid);if(me<0)fail('NOT_MEMBER');if(action==='get')return response(r,uid);
  if(r.lastRequests[uid]===requestId)return response(r,uid);if(r.status==='closed')fail('ROOM_CLOSED');
  if(action==='chat'){
   const text=typeof d.text==='string'?d.text.trim().slice(0,200):'';if(!text)fail('EMPTY_MESSAGE');if(Date.now()-(r.chatAt[uid]||0)<2000)fail('CHAT_RATE_LIMIT');r.chat.push({name:r.names[me],uid,text,time:Date.now()});r.chat=r.chat.slice(-40);r.chatAt[uid]=Date.now();r.lastRequests[uid]=requestId;tx.set(roomRef,r);return response(r,uid);
  }
  if(action==='report'){const text=typeof d.text==='string'?d.text.trim().slice(0,500):'';if(!text)fail('EMPTY_MESSAGE');tx.set(ref('reportsV2',uid+'-'+r.code),{from:uid,room:r.code,text,time:Date.now()});return response(r,uid);}
  if(d.version!==r.version)fail('STALE_STATE');let g=r.game?JSON.parse(r.game):null;
  if(action==='leave')r.status='closed';
  else if(action==='start'){if(me!==0||r.members.length!==r.capacity||r.status!=='waiting')fail('CANNOT_START');g=E.start(r.options);}
  else if(action==='next'){if(me!==0||!g||!g.finished)fail('CANNOT_START');g=E.start(r.options,g);}
  else{if(r.status!=='playing'||!g)fail('CANNOT_PLAY');try{E.act(g,me,action,d.tileId,d.side);}catch(e){fail(e.message);}}
  // Rankings are computed only by the server on completed public matchmaking matches.
  if(g&&g.matchFinished&&r.ranked&&r.awarded!==g.roundId){
   const docs=await Promise.all(r.members.map(id=>tx.get(ref('profilesV2',id))));
   docs.forEach((doc,i)=>{const p=doc.exists?doc.data():profile(r.members[i],r.names[i]);p.matches++;if(g.winner===i){p.wins++;p.cups+=20;}else if(g.winner>=0)p.cups=Math.max(0,p.cups-5);tx.set(ref('profilesV2',r.members[i]),p);});r.awarded=g.roundId;
  }
  if(g){r.game=JSON.stringify(g);if(action!=='leave')r.status=g.finished?'finished':'playing';}
  r.lastRequests[uid]=requestId;r.version++;r.expires=Date.now()+86400000;tx.set(roomRef,r);return response(r,uid);
 });
 };
};
