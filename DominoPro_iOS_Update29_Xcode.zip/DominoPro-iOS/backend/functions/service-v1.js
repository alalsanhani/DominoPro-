'use strict';
module.exports = function createService(db,fail) {
const crypto=require('node:crypto');
const E=require('./engine-v1');
function response(r,uid){const me=r.host===uid?0:r.guest===uid?1:-1;if(me<0)fail('NOT_MEMBER');return {code:r.code,status:r.status,version:r.version,me,names:r.names,game:E.view(r.game?JSON.parse(r.game):null,me)};}
function code(){const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';return Array.from({length:6},()=>alphabet[crypto.randomInt(alphabet.length)]).join('');}
return async request => {
 if(!request.auth)fail('SIGN_IN_REQUIRED');
 const uid=request.auth.uid,d=request.data||{},action=d.action;
 if(typeof action!=='string')fail('INVALID_REQUEST');
 const name=typeof d.name==='string'?d.name.trim().slice(0,24):'';
 const requestId=d.requestId;
 if(action!=='get'&&(typeof requestId!=='string'||!/^[A-Za-z0-9-]{8,80}$/.test(requestId)))fail('INVALID_REQUEST');
 if(action==='create'){
  const profile=db.collection('dominoUsers').doc(uid),newCode=code(),ref=db.collection('rooms').doc(newCode);
  return db.runTransaction(async tx=>{
   const user=await tx.get(profile);
   if(user.exists&&user.data().active){const old=await tx.get(db.collection('rooms').doc(user.data().active));if(old.exists&&old.data().status!=='closed'&&old.data().expires>Date.now())return response(old.data(),uid);}
   const collision=await tx.get(ref);if(collision.exists)fail('TRY_AGAIN');
   const r={code:newCode,host:uid,guest:'',names:[name||'Player 1','Player 2'],status:'waiting',block:d.block===true,version:1,game:'',lastRequests:{},created:Date.now(),expires:Date.now()+86400000};
   tx.create(ref,r);tx.set(profile,{active:newCode});return response(r,uid);
  });
 }
 if(typeof d.code!=='string'||!/^[A-Z2-9]{6}$/.test(d.code))fail('INVALID_CODE');
 const ref=db.collection('rooms').doc(d.code);
 return db.runTransaction(async tx=>{
  const doc=await tx.get(ref);if(!doc.exists)fail('ROOM_NOT_FOUND');const r=doc.data();
  if(r.expires<Date.now())fail('ROOM_EXPIRED');
  if(action==='join'){
   if(r.host===uid||r.guest===uid)return response(r,uid);
   if(r.status!=='waiting'||r.guest)fail('ROOM_FULL');
   r.guest=uid;r.names[1]=name||'Player 2';r.version++;tx.set(ref,r);tx.set(db.collection('dominoUsers').doc(uid),{active:r.code});return response(r,uid);
  }
  const me=r.host===uid?0:r.guest===uid?1:-1;if(me<0)fail('NOT_MEMBER');
  if(action==='get')return response(r,uid);
  if(r.lastRequests[uid]===requestId)return response(r,uid);
  if(r.status==='closed')fail('ROOM_CLOSED');
  if(d.version!==r.version)fail('STALE_STATE');
  if(action==='leave')r.status='closed';
  else if(action==='start'){
   if(me!==0||!r.guest||r.status!=='waiting')fail('CANNOT_START');const g=E.start(r.block);r.game=JSON.stringify(g);r.status=g.finished?'finished':'playing';
  }else if(action==='next'){
   const g=r.game?JSON.parse(r.game):null;
   if(me!==0||!g||!g.finished)fail('CANNOT_START');const next=E.start(r.block,g);r.game=JSON.stringify(next);r.status=next.finished?'finished':'playing';
  }else{
   if(r.status!=='playing')fail('CANNOT_PLAY');const g=JSON.parse(r.game);
   try{E.act(g,me,action,d.tileId,d.side);}catch(e){fail(e.message);}
   r.game=JSON.stringify(g);if(g.finished)r.status='finished';
  }
  r.lastRequests[uid]=requestId;r.version++;r.expires=Date.now()+86400000;
  tx.set(ref,r);return response(r,uid);
 });
};
};
