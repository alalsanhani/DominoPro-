'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
function fixture(){
 const records=new Map();let queue=Promise.resolve();
 const db={collection:c=>({doc:id=>({path:c+'/'+id})}),runTransaction:fn=>{
  const job=queue.then(async()=>{const writes=[];const result=await fn({get:async r=>({exists:records.has(r.path),data:()=>structuredClone(records.get(r.path))}),set:(r,v)=>writes.push([r.path,structuredClone(v)]),create:(r,v)=>{assert.ok(!records.has(r.path));writes.push([r.path,structuredClone(v)]);}});for(const [p,v] of writes)records.set(p,v);return result;});queue=job.catch(()=>{});return job;
 }};
 const service=require('../service-v1')(db,code=>{throw Error(code);});let seq=0;
 return {call:(uid,action,data={})=>service({auth:uid?{uid}:null,data:{action,requestId:'request-'+(++seq),...data}}),records};
}
test('authentication, private membership, concurrent joins, start and close',async()=>{
 const f=fixture();await assert.rejects(f.call(null,'create'),/SIGN_IN_REQUIRED/);
 const r=await f.call('a','create',{name:'Host'});assert.equal(r.status,'waiting');assert.equal(r.game,null);
 await assert.rejects(f.call('z','get',{code:r.code}),/NOT_MEMBER/);
 await assert.rejects(f.call('a','start',{code:r.code,version:r.version}),/CANNOT_START/);
 const joins=await Promise.allSettled(['b','c'].map(uid=>f.call(uid,'join',{code:r.code})));
 assert.equal(joins.filter(x=>x.status==='fulfilled').length,1);assert.equal(joins.filter(x=>x.status==='rejected').length,1);
 let view=await f.call('a','get',{code:r.code});view=await f.call('a','start',{code:r.code,version:view.version});assert.equal(view.status,'playing');assert.ok(view.game.hand);assert.equal(view.game.revealed.length,0);
 const closed=await f.call('a','leave',{code:r.code,version:view.version});assert.equal(closed.status,'closed');
});
test('duplicate action is idempotent and stale revisions rejected',async()=>{
 const f=fixture();let r=await f.call('a','create');await f.call('b','join',{code:r.code});r=await f.call('a','get',{code:r.code});r=await f.call('a','start',{code:r.code,version:r.version});
 const actor=r.game.turn===0?'a':'b',v=await f.call(actor,'get',{code:r.code}),g=v.game;
 const t=g.hand.find(t=>[g.board[0].a,g.board[g.board.length-1].b].some(n=>n===t.a||n===t.b));
 const action=t?'play':g.canDraw?'draw':'pass';const data={code:r.code,version:v.version,requestId:'same-request-001'};
 if(t){data.tileId=Math.min(t.a,t.b)*7+Math.max(t.a,t.b);data.side=t.a===g.board[0].a||t.b===g.board[0].a?0:1;}
 const changed=await f.call(actor,action,data),again=await f.call(actor,action,data);assert.equal(changed.version,again.version);assert.deepEqual(changed.game,again.game);
 await assert.rejects(f.call(actor,action,{...data,requestId:'new-request-002'}),/STALE_STATE/);
});
test('create resumes own active room; invalid code and expired room rejected',async()=>{const f=fixture(),r=await f.call('a','create');assert.equal((await f.call('a','create')).code,r.code);await assert.rejects(f.call('b','join',{code:'../bad'}),/INVALID_CODE/);f.records.get('rooms/'+r.code).expires=0;await assert.rejects(f.call('a','get',{code:r.code}),/ROOM_EXPIRED/);});
