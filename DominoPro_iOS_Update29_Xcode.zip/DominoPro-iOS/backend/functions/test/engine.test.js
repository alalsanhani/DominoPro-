const test=require('node:test'),assert=require('node:assert/strict'),E=require('../engine');
function verify(g){const ts=[...g.board,...g.stock,...g.hands.flat()];assert.equal(ts.length,28);assert.equal(new Set(ts.map(E.id)).size,28);if(!g.spinner){for(let i=1;i<g.board.length;i++)assert.equal(g.board[i-1].b,g.board[i].a);}else{let n=1;for(const arm of g.arms){let end=g.spinner.a;for(const t of arm){assert.equal(t.a,end);end=t.b;n++;}}assert.equal(n,g.board.length);}}
test('3600 rounds: all six variants, 2/3/4 players and topology invariants',()=>{
 for(let mode=0;mode<6;mode++)for(let players=2;players<=4;players++)for(let seed=0;seed<200;seed++){
  const g=E.start({mode,players,target:50});verify(g);let steps=0;
  while(!g.finished&&steps++<200){const p=g.turn;let found=false;for(const t of g.hands[p]){for(let side=0;side<(g.spinner?4:2);side++)if(E.legal(g,t,side)){E.act(g,p,'play',E.id(t),side);found=true;break;}if(found)break;}if(!found)E.act(g,p,g.block||!g.stock.length?'pass':'draw');verify(g);}
  assert.ok(g.finished);const v=E.view(g,0);assert.ok(!('stock' in v));assert.ok(!('hands' in v));
 }
});
test('private hand and no pre-finish reveal',()=>{const g=E.start({players:4}),v=E.view(g,1);assert.deepEqual(v.hand,g.hands[1]);assert.deepEqual(v.revealed,[]);assert.throws(()=>E.act(g,(g.turn+1)%4,'pass'),/NOT_YOUR_TURN/);});
