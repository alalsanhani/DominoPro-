'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),E=require('../engine-v1');
function check(g){const all=[...g.hands[0],...g.hands[1],...g.board,...g.stock];assert.equal(all.length,28);assert.equal(new Set(all.map(E.id)).size,28);for(let i=1;i<g.board.length;i++)assert.equal(g.board[i-1].b,g.board[i].a);}
test('2000 complete Draw/Block rounds conserve tiles, legal chains and scores',()=>{
 for(let n=0;n<2000;n++){
  const g=E.start(n%2===0);check(g);
  let steps=0;while(!g.finished&&steps++<160){const p=g.turn,m=g.hands[p].find(t=>E.legal(g,t,0)||E.legal(g,t,1));if(m)E.act(g,p,'play',E.id(m),E.legal(g,m,0)?0:1);else E.act(g,p,g.block||!g.stock.length?'pass':'draw');check(g);}
  assert.ok(g.finished);if(g.winner>=0)assert.equal(g.points,g.hands[1-g.winner].reduce((s,t)=>s+t.a+t.b,0));
 }
});
test('online view hides opponent hand and stock before game ends',()=>{const g=E.start(),v=E.view(g,0);assert.deepEqual(v.hand,g.hands[0]);assert.ok(!('hands' in v));assert.ok(!('stock' in v));assert.deepEqual(v.revealed,[]);});
test('reject wrong player, fabricated tile, draw/pass with a legal tile',()=>{const g=E.start();assert.throws(()=>E.act(g,1-g.turn,'draw'),/NOT_YOUR_TURN/);assert.throws(()=>E.act(g,g.turn,'play',100,0),/ILLEGAL_MOVE/);if(E.hasMove(g,g.turn)){assert.throws(()=>E.act(g,g.turn,'draw'),/CANNOT_DRAW/);assert.throws(()=>E.act(g,g.turn,'pass'),/CANNOT_PASS/);}});
test('block winner and ties',()=>{const g={hands:[[{a:1,b:2}],[{a:3,b:4}]],board:[{a:6,b:6}],stock:[{a:0,b:0}],scores:[0,0],turn:0,finished:false,block:true};E.act(g,0,'pass');assert.equal(g.winner,0);assert.equal(g.points,7);});
