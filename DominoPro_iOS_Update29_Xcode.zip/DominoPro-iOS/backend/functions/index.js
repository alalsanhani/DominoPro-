'use strict';
const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {initializeApp}=require('firebase-admin/app');
const {getFirestore}=require('firebase-admin/firestore');
initializeApp();
const fail=code=>{throw new HttpsError(code==='SIGN_IN_REQUIRED'?'unauthenticated':'failed-precondition',code);};
exports.domino=onCall({region:'us-central1',maxInstances:10,timeoutSeconds:30},require('./service-v1')(getFirestore(),fail));
exports.dominoV2=onCall({region:'us-central1',maxInstances:10,timeoutSeconds:30},require('./service')(getFirestore(),fail));
