'use strict';
const crypto=require('node:crypto');
const id=t=>Math.min(t.a,t.b)*7+Math.max(t.a,t.b),flip=t=>({a:t.b,b:t.a});
const sum=(g,p)=>g.hands[p].reduce((n,t)=>n+(g.mode===5&&t.a+t.b===0?10:t.a+t.b),0);
const sides=g=>g.spinner?4:2;
const end=(g,s)=>g.spinner?(g.arms[s].length?g.arms[s].at(-1).b:g.spinner.a):(s===0?g.board[0].a:g.board.at(-1).b);
function available(g,s){if(!Number.isInteger(s)||s<0||s>=sides(g))return false;if(!g.spinner)return true;if(g.mode===4&&g.arms.some(a=>!a.length))return !g.arms[s].length;return s<2||g.arms[0].length>0&&g.arms[1].length>0;}
const legal=(g,t,s)=>available(g,s)&&(t.a===end(g,s)||t.b===end(g,s));
const hasMove=(g,p)=>g.hands[p].some(t=>Array.from({length:sides(g)},(_,s)=>s).some(s=>legal(g,t,s)));
function spinner(g){if(g.spinner||g.mode<2||g.mode>4)return;const i=g.board.findIndex(t=>t.a===t.b);if(i<0)return;g.spinner=g.board[i];g.arms=[g.board.slice(0,i).reverse().map(flip),g.board.slice(i+1),[],[]];}
function endSum(g){if(!g.spinner){if(g.board.length===1)return g.board[0].a+g.board[0].b;const a=g.board[0],b=g.board.at(-1);return a.a+(a.a===a.b?a.a:0)+b.b+(b.a===b.b?b.b:0);}return g.arms.reduce((n,a,s)=>n+(a.length?a.at(-1).b*(a.at(-1).a===a.at(-1).b?2:1):s<2?g.spinner.a:0),0);}
function scoreEnds(g,p){if(g.mode!==2&&g.mode!==3)return;const n=endSum(g),div=g.mode===2?5:3;if(n>0&&n%div===0){g.scores[p]+=n;g.points=n;if(g.scores[p]>=g.target){g.winner=p;g.finished=true;g.matchFinished=true;}}}
function finish(g,w){g.finished=true;g.winner=w;g.points=0;if(g.mode===5){for(let p=0;p<g.players;p++){const n=sum(g,p);if(n>=13)g.scores[p]+=n;if(g.scores[p]>=g.target)g.matchFinished=true;}if(g.matchFinished){const best=Math.min(...g.scores),winners=g.scores.flatMap((s,i)=>s===best?[i]:[]);g.winner=winners.length===1?winners[0]:-1;}return;}
 if(w>=0){g.points=g.hands.reduce((n,_,p)=>n+(p===w?0:sum(g,p)),0);if(g.mode===2||g.mode===3)g.points=Math.max(0,g.points-sum(g,w));g.scores[w]+=g.points;if(g.scores[w]>=g.target)g.matchFinished=true;}}
function blocked(g){if(g.finished||(!g.block&&g.stock.length))return;if(g.hands.some((_,p)=>hasMove(g,p)))return;const totals=g.hands.map((_,p)=>sum(g,p)),best=Math.min(...totals),ws=totals.flatMap((n,p)=>n===best?[p]:[]);finish(g,ws.length===1?ws[0]:-1);}
function start(options={},prior=null){const mode=options.mode||0,players=options.players||2,target=options.target||100;
 let g,owner,opening;
 do{const stock=[];for(let a=0;a<=6;a++)for(let b=a;b<=6;b++)stock.push({a,b});for(let i=27;i>0;i--){const j=crypto.randomInt(i+1);[stock[i],stock[j]]=[stock[j],stock[i]];}
 g={players,mode,target,block:mode===1||mode===5,hands:Array.from({length:players},()=>[]),stock,board:[],arms:[],spinner:null,scores:prior&&!prior.matchFinished?[...prior.scores]:Array(players).fill(0),round:prior&&!prior.matchFinished?prior.round+1:1,roundId:crypto.randomUUID(),finished:false,matchFinished:false,winner:-2,turn:0,points:0};
 for(let n=0;n<7;n++)for(let p=0;p<players;p++)g.hands[p].push(stock.pop());let best=-1;for(let p=0;p<players;p++)for(const t of g.hands[p]){const rank=(t.a===t.b?100:0)+t.a+t.b;if(rank>best){best=rank;owner=p;opening=t;}}
 }while(mode===4&&opening.a!==opening.b);
 g.hands[owner].splice(g.hands[owner].indexOf(opening),1);g.board.push(opening);g.turn=(owner+1)%players;spinner(g);scoreEnds(g,owner);blocked(g);return g;
}
function act(g,p,action,tileId,side){if(g.finished||p!==g.turn)throw Error('NOT_YOUR_TURN');if(action==='play'){
 const i=g.hands[p].findIndex(t=>id(t)===tileId),t=g.hands[p][i];if(!t||!legal(g,t,side))throw Error('ILLEGAL_MOVE');g.hands[p].splice(i,1);g.points=0;
 if(g.spinner){const oriented=t.a===end(g,side)?t:flip(t);g.arms[side].push(oriented);g.board.push(oriented);}else{if(side===0)g.board.unshift(t.b===end(g,0)?t:flip(t));else g.board.push(t.a===end(g,1)?t:flip(t));spinner(g);}
 scoreEnds(g,p);if(g.finished)return;if(!g.hands[p].length){finish(g,p);return;}g.turn=(p+1)%g.players;
 }else if(action==='draw'){if(g.block||!g.stock.length||hasMove(g,p))throw Error('CANNOT_DRAW');g.hands[p].push(g.stock.pop());}
 else if(action==='pass'){if(hasMove(g,p)||(!g.block&&g.stock.length))throw Error('CANNOT_PASS');g.turn=(p+1)%g.players;}else throw Error('UNKNOWN_ACTION');blocked(g);
}
function view(g,p){if(!g)return null;return {players:g.players,mode:g.mode,target:g.target,board:g.board,arms:g.arms,hand:g.hands[p],counts:g.hands.map(h=>h.length),stockCount:g.stock.length,scores:g.scores,round:g.round,roundId:g.roundId,turn:g.turn,winner:g.winner,points:g.points,finished:g.finished,matchFinished:g.matchFinished,block:g.block,endSum:endSum(g),ends:Array.from({length:sides(g)},(_,s)=>end(g,s)),allowed:Array.from({length:sides(g)},(_,s)=>available(g,s)),...(g.spinner?{spinner:g.spinner}:{}),canDraw:!g.finished&&g.turn===p&&!g.block&&g.stock.length>0&&!hasMove(g,p),canPass:!g.finished&&g.turn===p&&!hasMove(g,p)&&(g.block||!g.stock.length),revealed:g.finished?g.hands:[]};}
module.exports={start,act,view,id,legal,hasMove,blocked,endSum};
