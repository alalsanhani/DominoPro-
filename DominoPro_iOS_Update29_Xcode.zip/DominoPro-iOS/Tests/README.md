Run from the project root. Requires Node.js.

```sh
node Tests/rules.test.js
node Tests/lan.test.js
npm install --no-save playwright@1.51.1
npx playwright install chromium
node Tests/ui.test.js
node Tests/gestures.test.js
```

Set BROWSER_PATH to an installed Chromium executable when needed. UI tests use local bundled files and save screenshots to output/. These are browser tests, not an iOS device build. FramingTest.java compiles with CrossplayWire.java from the accompanying Android project.
