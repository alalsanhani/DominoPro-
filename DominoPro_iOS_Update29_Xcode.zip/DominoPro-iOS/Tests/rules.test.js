'use strict';
const assert=require('node:assert/strict'),E=require('../DominoPro/Web/engine'),Room=require('../DominoPro/Web/room');let checks=0,rounds=0;
function check(v,m){assert.ok(v,m);checks++;}
for(let mode=0;mode<6;mode++)for(let players=2;players<=4;players++)for(let teams=0;teams<=(players===4?1:0);teams++)for(let run=0;run<30;run++){
 const options={mode,players,target:200,teamMode:!!teams,teams:[0,1,0,1],teamNames:['A','B']};let g=E.start(options);
 for(let round=0;round<3;round++){
  let steps=0;while(!g.finished&&steps++<350){const oldTurn=g.turn,oldBoard=g.board.length;E.timeout(g);check(g.finished||g.turn!==oldTurn||g.board.length!==oldBoard,'Timeout finishes a turn');
   const ids=[...g.board,...g.stock,...g.hands.flat()].map(E.id);check(ids.length===28&&new Set(ids).size===28,'28 unique tiles conserved');
   if(g.spinner){for(let s=0;s<4;s++){let endpoint=g.spinner.a;for(const tile of g.arms[s]){check(tile.a===endpoint,'Spinner chain connected');endpoint=tile.b;}}}else for(let i=1;i<g.board.length;i++)check(g.board[i-1].b===g.board[i].a,'Linear chain connected');
   if(teams)check(g.scores[0]===g.scores[2]&&g.scores[1]===g.scores[3],'Team totals mirror');
   const view=E.view(g,0);check(!('hands'in view)&&!('stock'in view),'Opponent hands and stock private');check(g.finished||view.revealed.length===0,'No early reveal');
  }
  check(g.finished,'Round completes');check(g.roundResults.at(-1).round===g.round,'Round ledger updated');rounds++;
  const old=g;g=E.start(options,g);if(!old.matchFinished){check(g.tileStyle===old.tileStyle,'Material constant during match');check(g.scores.every((s,p)=>s>=old.scores[p]),'Scores retained');if(old.winner>=0&&!old.hands[old.winner].length)check(g.hands[old.winner].length===6,'Direct winner opens next');}
 }
}
const assignments=[-1,-1,-1,-1];E.chooseTeam(assignments,0,1);assert.throws(()=>E.chooseTeam(assignments,1,1));E.chooseTeam(assignments,1,0);E.chooseTeam(assignments,2,1);E.chooseTeam(assignments,3,0);check(E.completeTeams(assignments),'Alternating team selection');
const r=new Room({players:4,mode:0,target:50,teamMode:true,teamNames:['A','B']},'Host','123456');
assert.throws(()=>r.hello(11,{protocol:1,pin:'000000',secret:'x'.repeat(30)}));
for(let p=1;p<=3;p++)r.hello(10+p,{protocol:1,pin:'123456',secret:String(p).repeat(30),name:'Phone '+p});check(r.ready(),'Four phones connected');
function action(peer,a,extra={}){r.action(peer,{action:a,version:r.version,...extra},1000);}
action(0,'start');check(!r.game&&r.queued,'Start waits for team selection');
for(let p=0;p<4;p++)action(p===0?0:10+p,'team',{side:p%2});check(!!r.game,'Starts after fourth team selection');
const publicState=JSON.stringify(r.snapshot(1,1000));check(!publicState.includes('secrets')&&!publicState.includes('123456')&&!publicState.includes('hands'),'Snapshots private');
assert.throws(()=>r.action(99,{action:'play',version:r.version},1000));assert.throws(()=>r.action(11,{action:'start',version:r.version},1000));
const before=r.version;r.tick(21001);check(r.version>before,'Authoritative timeout advances');r.lose(12);check(!r.ready()&&!r.deadline,'Disconnect pauses');
r.hello(42,{protocol:1,pin:'123456',secret:'2'.repeat(30),name:'Phone 2'});r.tick(22000);check(r.ready()&&r.deadline===42000,'Reconnect resumes with fresh deadline');
action(0,'configure',{options:{players:4,mode:1,target:100,teamMode:false}});check(!r.game&&r.peers[2]===42,'Reconfigure preserves connection');
console.log(JSON.stringify({rounds,checks,roomTests:'passed'}));
