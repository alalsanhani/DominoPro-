import com.alukaal.dominopro.CrossplayWire;
import java.io.*;
import java.nio.charset.StandardCharsets;
public class FramingTest {
 public static void main(String[] args)throws Exception {
  String json="{\"name\":\"جهاز المضيف\",\"type\":\"hello\",\"players\":4}";
  ByteArrayOutputStream bytes=new ByteArrayOutputStream();CrossplayWire.write(new DataOutputStream(bytes),json);
  byte[] frame=bytes.toByteArray();int n=0;for(int i=0;i<4;i++)n=(n<<8)|(frame[i]&255);
  if(n!=json.getBytes(StandardCharsets.UTF_8).length)throw new AssertionError("Byte length");
  InputStream fragmented=new ByteArrayInputStream(frame){public synchronized int read(byte[] b,int o,int l){return super.read(b,o,Math.min(l,1));}};
  if(!json.equals(CrossplayWire.read(new DataInputStream(fragmented))))throw new AssertionError("Fragmented UTF8");
  for(byte[] bad:new byte[][]{{0,0,0,0},{0,1,0,1},{-1,-1,-1,-1},{0,0,0,3,65}}){try{CrossplayWire.read(new DataInputStream(new ByteArrayInputStream(bad)));throw new AssertionError("Rejected size/truncation");}catch(IOException expected){}}
  System.out.println("Framing: UTF-8, fragmented reads, byte ordering, bounds and truncation passed");
 }
}
